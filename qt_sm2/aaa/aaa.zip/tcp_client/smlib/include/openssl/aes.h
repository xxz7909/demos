/*
 * Copyright 2002-2016 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the OpenSSL license (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#ifndef HEADER_sm2_H
# define HEADER_sm2_H

# include <openssl/opensslconf.h>

# include <stddef.h>
# ifdef  __cplusplus
extern "C" {
# endif

# define sm2_ENCRYPT     1
# define sm2_DECRYPT     0

/*
 * Because array size can't be a const in C, the following two are macros.
 * Both sizes are in bytes.
 */
# define sm2_MAXNR 14
# define sm2_BLOCK_SIZE 16

/* This should be a hidden type, but EVP requires that the size be known */
struct sm2_key_st {
# ifdef sm2_LONG
    unsigned long rd_key[4 * (sm2_MAXNR + 1)];
# else
    unsigned int rd_key[4 * (sm2_MAXNR + 1)];
# endif
    int rounds;
};
typedef struct sm2_key_st sm2_KEY;

const char *sm2_options(void);

int sm2_set_encrypt_key(const unsigned char *userKey, const int bits,
                        sm2_KEY *key);
int sm2_set_decrypt_key(const unsigned char *userKey, const int bits,
                        sm2_KEY *key);

void sm2_encrypt(const unsigned char *in, unsigned char *out,
                 const sm2_KEY *key);
void sm2_decrypt(const unsigned char *in, unsigned char *out,
                 const sm2_KEY *key);

void sm2_ecb_encrypt(const unsigned char *in, unsigned char *out,
                     const sm2_KEY *key, const int enc);
void sm2_cbc_encrypt(const unsigned char *in, unsigned char *out,
                     size_t length, const sm2_KEY *key,
                     unsigned char *ivec, const int enc);
void sm2_cfb128_encrypt(const unsigned char *in, unsigned char *out,
                        size_t length, const sm2_KEY *key,
                        unsigned char *ivec, int *num, const int enc);
void sm2_cfb1_encrypt(const unsigned char *in, unsigned char *out,
                      size_t length, const sm2_KEY *key,
                      unsigned char *ivec, int *num, const int enc);
void sm2_cfb8_encrypt(const unsigned char *in, unsigned char *out,
                      size_t length, const sm2_KEY *key,
                      unsigned char *ivec, int *num, const int enc);
void sm2_ofb128_encrypt(const unsigned char *in, unsigned char *out,
                        size_t length, const sm2_KEY *key,
                        unsigned char *ivec, int *num);
/* NB: the IV is _two_ blocks long */
void sm2_ige_encrypt(const unsigned char *in, unsigned char *out,
                     size_t length, const sm2_KEY *key,
                     unsigned char *ivec, const int enc);
/* NB: the IV is _four_ blocks long */
void sm2_bi_ige_encrypt(const unsigned char *in, unsigned char *out,
                        size_t length, const sm2_KEY *key,
                        const sm2_KEY *key2, const unsigned char *ivec,
                        const int enc);

int sm2_wrap_key(sm2_KEY *key, const unsigned char *iv,
                 unsigned char *out,
                 const unsigned char *in, unsigned int inlen);
int sm2_unwrap_key(sm2_KEY *key, const unsigned char *iv,
                   unsigned char *out,
                   const unsigned char *in, unsigned int inlen);


# ifdef  __cplusplus
}
# endif

#endif
