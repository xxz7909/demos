#include "openssl/ossl_typ.h"
#include "stddef.h"

#define SUCCESS 1
#define FAILURE 0
